math.randomseed(os.time())

money = 0
fish_in_river = 1
goldfish_chance = 1

function spawn_fish()
  return math.random(100) <= goldfish_chance and "gold" or "normal"
end

function catch_fish(type)
  local earned = (type == "gold") and 2 or 1
  money = money + earned
  return {money = money}
end

function buy_upgrade(cost, new_fish, new_chance)
  if money < cost then return {} end
  money = money - cost
  fish_in_river = new_fish
  goldfish_chance = new_chance
  return {money = money, fish = fish_in_river, chance = goldfish_chance}
end
