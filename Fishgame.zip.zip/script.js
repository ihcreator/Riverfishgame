// HTML elements
const river = document.getElementById("river");
const catchBtn = document.getElementById("catchBtn");
const tropicalUpgradeBtn = document.getElementById("tropicalUpgrade");
const valueUpgradeBtn = document.getElementById("valueUpgrade");
const autoUpgradeBtn = document.getElementById("autoUpgrade");
const moneyEl = document.getElementById("money");

// Game state
let money = 0;
let fishes = [];
let spawnScheduled = false;
let autoEnabled = false;
let autoCatchInterval = null;

// Tropical upgrade state
const tropicalPrices = [30, 90, 270, 810, 2430];
let tropicalStage = 0;
let tropicalChance = 1;
let tropicalPrice = tropicalPrices[0];

// Value upgrade state
let upgradeLevel = 0;
const upgradeCosts = [10, 40, 260, 999, 2430];
const fishValues = [1, 2, 4, 8, 16, 32];
const tropicalValues = [30, 60, 120, 240, 500, 1000];

// Setup single catch listener
catchBtn.addEventListener("click", () => {
  if (catchBtn.disabled) return;
  catchBtn.disabled = true;
  catchFish();
});

// Update UI based on current state
function updateUI() {
  moneyEl.textContent = `Money: $${money}`;

  const tropicalMaxed = tropicalStage >= tropicalPrices.length;
  tropicalUpgradeBtn.disabled = tropicalMaxed || money < tropicalPrice || tropicalChance >= 16;
  tropicalUpgradeBtn.textContent = tropicalMaxed
    ? "Tropical — Maxed"
    : `Tropical Chance ×2 ($${tropicalPrice})`;

  const valueCost = upgradeCosts[upgradeLevel];
  const valueMaxed = valueCost == null;
  valueUpgradeBtn.disabled = valueMaxed || money < valueCost;
  valueUpgradeBtn.textContent = valueMaxed
    ? "Max Value"
    : `Increase Value ($${valueCost})`;

  autoUpgradeBtn.disabled = money < 299 || autoEnabled;
  catchBtn.disabled = fishes.length === 0;
}

// Create and animate fish
function createFish(isTropical) {
  const fish = document.createElement("div");
  fish.className = "fish";
  fish.textContent = isTropical ? "🐠" : "🐟";
  river.appendChild(fish);

  const fishObj = { elem: fish, isTropical, caught: false };
  fishes.push(fishObj);

  fish.animate(
    [{ left: "-50px" }, { left: `${river.clientWidth}px` }],
    { duration: 3000, easing: "linear" }
  ).onfinish = () => {
    if (!fishObj.caught) {
      fish.remove();
      fishes.splice(fishes.indexOf(fishObj), 1);
      scheduleRespawn();
      updateUI();
    }
  };
}

// Spawn logic
function spawnAllFish() {
  fishes.forEach(f => f.elem.remove());
  fishes = [];
  createFish(Math.random() * 100 < tropicalChance);
  updateUI();
}

// Respawn fish after delay
function scheduleRespawn() {
  if (!spawnScheduled) {
    spawnScheduled = true;
    setTimeout(() => {
      spawnScheduled = false;
      spawnAllFish();
    }, 2000);
  }
}

// Catch fish and reward
function catchFish() {
  if (fishes.length === 0) return;
  const fishObj = fishes[0];
  if (fishObj.caught) return;

  fishObj.caught = true;
  fishObj.elem.remove();
  fishes.shift();

  money += fishObj.isTropical ? tropicalValues[upgradeLevel] : fishValues[upgradeLevel];
  scheduleRespawn();
  updateUI();
}

// Tropical upgrade logic
tropicalUpgradeBtn.addEventListener("click", () => {
  if (money < tropicalPrice || tropicalStage >= tropicalPrices.length) return;
  money -= tropicalPrice;
  tropicalChance = Math.min(tropicalChance * 2, 16);
  tropicalStage++;
  if (tropicalStage < tropicalPrices.length) {
    tropicalPrice = tropicalPrices[tropicalStage];
  }
  updateUI();
});

// Value upgrade logic
valueUpgradeBtn.addEventListener("click", () => {
  const cost = upgradeCosts[upgradeLevel];
  if (cost == null || money < cost) return;
  money -= cost;
  upgradeLevel++;
  updateUI();
});

// Auto-catcher logic
autoUpgradeBtn.addEventListener("click", () => {
  if (money < 299 || autoEnabled) return;
  money -= 299;
  autoEnabled = true;
  updateUI();
  autoCatchInterval = setInterval(() => {
    if (fishes.length && !catchBtn.disabled) {
      catchFish();
      catchBtn.disabled = true;
    }
  }, 1000);
});

// Start game
spawnAllFish();
updateUI();
